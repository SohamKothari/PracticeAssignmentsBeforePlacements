
// 9.Write a Java Program to Print 1 To 10 Without Using Loop.
import java.util.Scanner;

public class PrintWithoutLoop {
    public static void pRint(int N, int temp) {
        /*
         * if (n <= 10) {
         * System.out.println(n);
         * pRint(n + 1);
         * }
         */

        if (N <= temp) {
            System.out.println(N);
            pRint(N + 1, temp);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        System.out.println("!!! Start !!!");
        pRint(1, N); /* pRint(1); */
        System.out.println("!!! End !!!");
    }
}
/*
 * 1.Check the given number is EVEN or ODD.
 * 2.Write a Java Program to find the Factorial of given number.
 * 3.Find the Factorial of a number using Recursion.
 * 4.Swap two numbers without using third variable approach 1.
 * 5.Swap two numbers without using third variable approach 2.
 * 6.Swap two numbers without using third variable approach 3.
 * 7.How to check the given number is Positive or Negative in Java?
 * 8.Write a Java Program to find whether given number is Leap year or NOT?
 * 9.Write a Java Program to Print 1 To 10 Without Using Loop.
 * 10.Write a Java Program to print the digits of a Given Number.
 * 11.Write a Java Program to print all the Factors of the Given number.
 * 12.Write a Java Program to find sum of the digits of a given number.
 * 13.Write a Java Program to find the smallest of 3 numbers (a,b,c) without
 * using < or > symbol?
 * 14.How to add two numbers without using the arithmetic operators in Java?
 * 15.Write a java program to Reverse a given number.
 * 16.Write a Java Program to find GCD of two given numbers.
 * 17.Write a java program to LCM of TWO given number.
 * 18.Write a java program to LCM of TWO given number using Prime Factors
 * method.
 * 19.Check whether the Given Number is a Palindrome or NOT.
 * 20.Write a Java Program to print all the Prime Factors of the Given Number.
 */