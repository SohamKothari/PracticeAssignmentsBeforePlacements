
/* 8.Write a Java Program to find whether given number is Leap year or NOT? */

import java.util.Scanner;

class LeapYear {
    public static void main(String[] args) {
        System.out.println("Enter Year :");
        Scanner scan = new Scanner(System.in);
        int Yr = scan.nextInt();
        if (((Yr % 4 == 0) && (Yr % 100 != 0)) || (Yr % 400 == 0))
            System.out.println("Is a Leap Year");
        else
            System.out.println("Is not a Leap Year");
    }
}
