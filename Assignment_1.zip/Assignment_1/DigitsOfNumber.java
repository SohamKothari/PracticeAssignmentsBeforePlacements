
/*  10.Write a Java Program to print the digits of a Given Number.*/
import java.util.*;

public class DigitsOfNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /* Method 1 : Using While Loop and Remainder as 2nd Variable */
        int Num = 0, remainder = 0, sum = 0;
        System.out.println("Enter any Number : ");
        Num = sc.nextInt();
        while (Num > 0) {
            remainder = Num % 10;
            System.out.println("\t \t '" + remainder + "'");
            Num = Num / 10;
            sum = sum + remainder; /* 12.Write a Java Program to find sum of the digits of a given number. */
        }
        System.out.println("\t \t Sumof digits =  '" + sum + "'");
        /*
         * Method 2 : Converting Number into String and then using CharAt string method
         */
        System.out.println("Enter a Number : ");
        int Number = sc.nextInt();
        String string_rep_of_number = Integer.toString(Number);
        for (int i = 0; i < string_rep_of_number.length(); i++) {
            System.out.print("Digit at " + (i + 1) + "th Place " + string_rep_of_number.charAt(i) + ". \n");
        }

        /* Method 3 : Using 2 while loops. */
        int n, temp, digit, count = 0;
        // object of the Scanner class
        System.out.print("Enter any number: ");
        // getting input from the user
        n = sc.nextInt();
        // copy the entered number in a temp variable
        temp = n;
        // the loop determines the position of the digit
        while (n > 0) {
            // dividing the number by 10
            n = n / 10;
            // increments the count variable by 1
            count++;
        }
        sum = 0;
        // the loop breaks the number into digits
        while (temp > 0) {
            // finding the remainder
            digit = temp % 10;
            // prints the position and digit
            System.out.println("Digit at place " + count + " is: " + digit);
            temp = temp / 10;
            // decrements the digit by 1
            count--;
        }
    }
}
