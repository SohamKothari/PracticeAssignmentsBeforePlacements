import java.util.Scanner;

/* 17.Write a java program to LCM of TWO given number.*/

/* Least Common Multiple */
public class LCM {
    static int lcm;

    public static void main(String[] args) {
        System.out.println("Enter two numbers :");
        Scanner sc = new Scanner(System.in);
        int N1 = sc.nextInt();
        int N2 = sc.nextInt();
        System.out.println("\n Method-1 :");
        System.out.println("Instance Variable Before LCM = " + lcm);
        System.out.println("\n LCM for Method-1 = " + lcm_Method_1(N1, N2));
        System.out.println("Instance Variable After LCM = " + lcm);
        System.out.println("\n Method-2 :");
        System.out.println("Instance Variable Before LCM = " + lcm);
        System.out.println("\n LCM for Method-2 = " + lcm_Method_2(N1, N2));
        System.out.println("Instance Variable After LCM = " + lcm);
        System.out.println("\n Method-3 :");
        System.out.println("LCM of " + N1 +
                " and " + N2 +
                " is " + lcm_Method_3(N1, N2));
    }

    private static int lcm_Method_1(int n1, int n2) {
        lcm = (n1 > n2) ? n1 : n2;
        while (true) {
            if (lcm % n1 == 0 && lcm % n2 == 0) {
                System.out.printf("The LCM of %d and %d is %d.", n1, n2, lcm);
                break;
            }
            ++lcm;
        }
        return lcm;
    }

    private static int lcm_Method_2(int n1, int n2) {
        int gcd = 1;
        for (int i = 1; i <= n1 && i <= n2; ++i) {
            // Checks if i is factor of both integers
            if (n1 % i == 0 && n2 % i == 0)
                gcd = i;
        }
        lcm = (n1 * n2) / gcd;
        System.out.printf("The LCM of %d and %d is %d.", n1, n2, lcm);
        return lcm;
    }

    static int gcd(int a, int b) {
        if (a == 0)
            return b;
        return gcd(b % a, a);
    }

    // method to return LCM of two numbers
    static int lcm_Method_3(int a, int b) {
        return (a / gcd(a, b)) * b;
    }
}
