
/* 16.Write a Java Program to find GCD of two given numbers.*/
import java.util.*;

/* GCD - Greatest Common Divisor , GCF - Greatest Common Factor , HCF - Highest Common Factor */
/* GCD / HCF / GCF */
public class GCDofTwo {
    static int gcd = 1;

    public static void main(String[] args) {
        System.out.println("Enter two numbers :");
        Scanner sc = new Scanner(System.in);
        int N1 = sc.nextInt();
        int N2 = sc.nextInt();
        System.out.println("Instance Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-1 = " + gcd_Method_1(N1, N2));
        System.out.println("Instance Variable After GCD = " + gcd);
        N1 = sc.nextInt();
        N2 = sc.nextInt();
        System.out.println("Class Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-2 = " + gcd_Method_2(N1, N2));
        System.out.println("Class Variable After GCD = " + gcd);
        N1 = sc.nextInt();
        N2 = sc.nextInt();
        System.out.println("Instance Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-3 = " + gcd_Method_3(N1, N2));
        System.out.println("Instance Variable After GCD = " + gcd);
        N1 = sc.nextInt();
        N2 = sc.nextInt();
        System.out.println("Class Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-4 = " + gcd_Method_4(N1, N2));
        System.out.println("Class Variable After GCD = " + gcd);
        N1 = sc.nextInt();
        N2 = sc.nextInt();
        System.out.println("Intance Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-5 = " + gcd_Method_5(N1, N2));
        System.out.println("Instance Variable After GCD = " + gcd);
        N1 = sc.nextInt();
        N2 = sc.nextInt();
        System.out.println("Global Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-6 = " + gcd_Method_6(N1, N2));
        System.out.println("Global Variable After GCD = " + gcd);
        N1 = sc.nextInt();
        N2 = sc.nextInt();
        System.out.println("Global Variable Before GCD = " + gcd);
        System.out.println("GCD for Method-7 = " + gcd_Method_7(N1, N2));
        System.out.println("Global Variable After GCD = " + gcd);
    }

    private static int gcd_Method_6(int a, int b) {
        if (b == 0)
            return a;
        return gcd_Method_6(b, a % b);
    }

    private static int gcd_Method_7(int a, int b) {
        // Everything divides 0
        if (a == 0)
            return b;
        if (b == 0)
            return a;
        if (a == b)
            return a;
        if (a > b)
            return gcd_Method_7(a - b, b);
        return gcd_Method_7(a, b - a);
    }

    private static int gcd_Method_5(int x, int y) {
        int r = 0, a, b;
        a = (x > y) ? x : y; // a is greater number
        b = (x < y) ? x : y; // b is smaller number
        r = b;
        while (a % b != 0) {
            r = a % b;
            a = b;
            b = r;
        }
        return gcd = r;
    }

    private static int gcd_Method_4(int a, int b) {
        while (b != 0) {
            if (a > b) {
                a = a - b;
            } else {
                b = b - a;
            }
        }
        return gcd = a;
    }

    private static int gcd_Method_3(int Num1, int Num2) {
        int Temp = 0;
        while (Num2 != 0) {
            Temp = Num2;
            Num2 = Num1 % Num2;
            Num1 = Temp;
        }
        return (gcd = Num1);
    }

    /* Method-1 : Using FOR Loop and Modulus Operator. */
    public static int gcd_Method_1(int x, int y) {
        // x and y parameters are the numbers to find the GCF
        // running loop form 1 to the smallest of both numbers
        for (int i = 1; i <= x && i <= y; i++) {
            // returns true if both conditions are satisfied
            if (x % i == 0 && y % i == 0)
                gcd = i; /* storing the variable i in the variable gcd */
        }
        return gcd;
    }

    /* Method-2 : Using FOR Loop and Modulus Operator. */
    public static int gcd_Method_2(int n1, int n2) {
        while (n1 != n2) {
            if (n1 > n2)
                n1 = n1 - n2;
            else
                n2 = n2 - n1;
        }
        return gcd = n2;
    }
}
