
/*15.Write a java program to Reverse a given number.*/
import java.util.*;

public class ReverseNumber {
    public static void main(String[] args) {
        System.out.print("Enter a Number :");
        Scanner sc = new Scanner(System.in);
        int Number = sc.nextInt();
        revMethod_1(Number);
        revMethod_2(Number);
        revMethod_3(Number);
        System.out.println("The reverse of the given number is: " + revMethod_4(Number));
    }

    /* Method-1 : Reversing using while Loop. */
    public static void revMethod_1(int number) {
        int reverse = 0;
        while (number != 0) {
            int remainder = number % 10;
            reverse = reverse * 10 + remainder;
            number = number / 10;
        }
        System.out.println("The reverse of the given number is: " + reverse);
    }

    /* Method-2 : Reversing using for Loop. */
    public static void revMethod_2(int number) {
        int reverse = 0;
        // we have not mentioned the initialization part of the for loop
        for (; number != 0; number = number / 10) {
            int remainder = number % 10;
            reverse = reverse * 10 + remainder;
        }
        /*
         * Above Loop or this Loop O/P is same :
         * for (; number != 0;) {
         * int remainder = number % 10;
         * reverse = reverse * 10 + remainder;
         * number = number / 10;
         * }
         */
        System.out.println("The reverse of the given number is: " + reverse);
    }

    /* Method-3 : Using Recursion. */
    public static void revMethod_3(int number) {
        if (number < 10) {
            // prints the same number if the number is less than 10
            System.out.println(number);
            return;
        } else {
            System.out.print(number % 10);
            revMethod_3(number / 10);
        }
    }

    /* Method-4 : Using Loop and BOOLEAN Primitive DataType. */
    public static int revMethod_4(int number) {
        boolean isNoNegative = number < 0 ? true : false;
        if (isNoNegative) {
            number = number * -1; // makes the number positive if the given number is negative
        }
        int reverse = 0;
        int lastDigit = 0;
        while (number >= 1) {
            lastDigit = number % 10; // gives the last digit of the number
            reverse = reverse * 10 + lastDigit;
            number = number / 10; // removes the last digit of the number
        }
        // makes the number negative
        return isNoNegative == true ? reverse * -1 : reverse;
    }
}
