/* 4.Swap two numbers without using third variable approach 1.
 * 5.Swap two numbers without using third variable approach 2.
 * 6.Swap two numbers without using third variable approach 3. */

import java.util.*;

class Swap {
    public static void swap1(int a, int b) {
        System.out.println("Before Swapping :" + a + "," + b);
        a = a + b;
        b = a - b;
        a = a - b;
        System.out.println("After Swapping :" + a + "," + b);
    }

    public static void swap2(int a, int b) {
        System.out.println("Before Swapping :" + a + "," + b);
        a = a * b;
        b = a / b;
        a = a / b;
        System.out.println("After Swapping :" + a + "," + b);
    }

    public static void swap3(int a, int b) {
        System.out.println("Before Swapping :" + a + "," + b);
        a = a ^ b;
        b = a ^ b;
        a = a ^ b;
        System.out.println("After Swapping :" + a + "," + b);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = 0, b = 0;
        System.out.print("Enter two Number : ");
        a = sc.nextInt();
        b = sc.nextInt();
        // SwapWithoutTemporary O1 = new SwapWithoutTemporary();
        swap1(a, b);
        System.out.print("Enter two Number again : ");
        a = sc.nextInt();
        b = sc.nextInt();
        swap2(a, b);
        System.out.print("Enter two Number again : ");
        a = sc.nextInt();
        b = sc.nextInt();
        swap3(a, b);
    }
}

/*
 * class SwapWithoutTemporary {
 * public int swap1(int a, int b) {
 * System.out.println("Before Swapping :" + a + "," + b);
 * a = a + b;
 * b = a - b;
 * a = a - b;
 * System.out.println("After Swapping :" + a + "," + b);
 * }
 * 
 * public int swap2(int a, int b) {
 * System.out.println("Before Swapping :" + a + "," + b);
 * a = a * b;
 * b = a / b;
 * a = a / b;
 * System.out.println("After Swapping :" + a + "," + b);
 * }
 * }
 */
