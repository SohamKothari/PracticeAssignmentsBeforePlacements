
/*  7.How to check the given number is Positive or Negative in Java? */
import java.util.Scanner;

public class PosNeg {
    public static void main(String[] args) {
        Scanner S1 = new Scanner(System.in);
        System.out.println("Enter any Number : ");
        int Num = S1.nextInt();
        if (Num > 0)
            System.out.println("Positive");
        else if (Num < 0)
            System.out.println("Negative");
        else
            System.out.println("Zero");
    }

}
