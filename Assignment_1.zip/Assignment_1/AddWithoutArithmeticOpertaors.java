/* 14.How to add two numbers without using the arithmetic operators in Java?*/

import java.util.Scanner;

class AddWithoutArithmeticOpertaors {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Two Numbers to ADD : ");
        int N1 = sc.nextInt();
        int N2 = sc.nextInt();
        System.out.println(
                "Using XOR and AND operators : Sum of " + N1 + " and " + N2 + " = '" + aDD_Meth1(N1, N2) + "'");
        System.out.println(
                "Using BITWISE OPERATORS and Recusrion : Sum of " + N1 + " and " + N2 + " = ` " + aDD_Meth2(N1, N2)
                        + " `");
        System.out.println("Direct Mehthod : Sum of " + N1 + " and " + N2 + " = ` " + (N1 + N2) + " `");
    }

    private static int aDD_Meth1(int a, int b) {
        while (b != 0) {
            int carry = (a & b); // CARRY is AND of two bits

            a = a ^ b; // SUM of two bits is A XOR B

            b = carry << 1; // shifts carry to 1 bit to calculate sum
        }
        return a;
    }

    public static int aDD_Meth2(int a, int b) {
        if (b == 0)
            return a;
        int sum = a ^ b; // SUM of two integer is A XOR B
        int carry = (a & b) << 1; // CARRY of two integer is A AND B
        return aDD_Meth2(sum, carry);
    }
}