
/* 11.Write a Java Program to print all the Factors of the Given number.*/
import java.util.*;

public class FindFactors {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any Number : ");
        int Num = sc.nextInt();
        int temp = 1, i = 1, j = 1, k = 1;
        temp = Num;
        if (Num == 0)
            System.out.println("Error! Error! # Zero has no Factors ");
        else if (Num > 0) {
            System.out.println(Num + " is a Positive Integer.");
            for (i = 1; i < temp; ++i) {
                if ((Num % i) == 0) {
                    System.out.println("Factor Number " + j + " = " + i);
                    j++;
                }
            }
        } else {
            System.out.println(Num + " is a Negative Integer.");
            for (i = temp; i <= Math.abs(temp) /* (i <= (-temp) && i >= temp) */; i++) {
                if (i == 0) {
                    continue;
                } else if ((Num % i) == 0) {
                    System.out.println("Factor Number " + k + " = " + i);
                    k++;
                }
            }
        }
    }
}
