
/*2.Write a Java Program to find the Factorial of given number. */
import java.util.*;

public class Factorial {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any Number : ");
        long Num = sc.nextInt();
        long fact = 1;
        if (Num == 0 || Num == 1)
            System.out.println("Factorial of " + Num + " = " + fact);
        else {
            for (long i = Num; i > 0; i--) {
                fact = fact * i;
            }
        }
        System.out.println("Factorial of " + Num + "=" + fact);
    }
}
/*
 * 
 * class Factorial {
 * 
 * public static void main(String args[]) {
 * BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
 * int a = 0, f = 1;
 * try {
 * System.out.println("Enter the number to find factorial:");
 * a = Integer.parseInt(bf.readLine());
 * } catch (Exception e) {
 * e.printStackTrace();
 * }
 * if (a == 0 || a == 1)
 * System.out.println("factorial of this number is 1");
 * else {
 * for (int i = a; i > 0; i--) {
 * f = f * i;
 * }
 * System.out.println("factorial of this number is:" + f);
 * }
 * }
 * }
 */