
/* Check the given number is EVEN or ODD.  */
import java.util.*;

class OddEven {

    public static void main(String[] args) {
        Scanner S1 = new Scanner(System.in);
        System.out.println("Enter any Number : ");
        int Value = S1.nextInt();
        if ((Value % 2) == 0)
            System.out.println("Even");
        else
            System.out.println("Odd");
    }

}
