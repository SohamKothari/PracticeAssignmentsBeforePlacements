/* 20.Write a Java Program to print all the Prime Factors of the Given Number.*/
public class PrintPRIMEfactors {
    public static void main(String[] args) {

    }
}
