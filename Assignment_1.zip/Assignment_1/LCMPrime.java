/* 18.Write a java program to LCM of TWO given number using Prime Factors method. */
public class LCMPrime {
   public static void main(String[] args) {
       
   } 
}
