
/*13.Write a Java Program to find the smallest of 3 numbers (a,b,c) without using < or > symbol? */
import java.util.Scanner;

public class SmallestNumber {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Three-3 Numbers : ");
        int N1 = sc.nextInt();
        int N2 = sc.nextInt();
        int N3 = sc.nextInt();
        System.out.println("Samllest Number using Repeated Subtraction = " + findSmallestMethod1(N1, N2, N3));
        System.out.println("Samllest Number using Bit Operations = " + findSmallestMethod2(N1, N2, N3));
        System.out.println("Samllest Number using Direct Comparison = " + compare(N1, N2, N3));
        System.out.println("Samllest Number using Division(/) Operator= " + findSmallestMethod3(N1, N2, N3));
    }

    /* Method-3 : Using Division Operator. */
    private static int findSmallestMethod3(int x, int y, int z) {
        {
            if ((y / x) != 1) // Same as "if (y < x)"
                return ((y / z) != 1) ? y : z;
            else
                return ((x / z) != 1) ? x : z;
        }
    }

    /* Direct Comparison Method */
    private static int compare(int n1, int n2, int n3) {
        if (n1 < n2 && n1 < n3)
            return n1;
        else if (n2 < n1 && n2 < n3)
            return n2;
        else
            return n3;
    }

    /* Method-1 : Repeated Subtraction */
    private static int findSmallestMethod1(int n1, int n2, int n3) {
        int c = 0;
        if (n1 < 0 || n2 < 0 || n3 < 0)
            return 0;
        while (n1 != 0 && n2 != 0 && n3 != 0) {
            n1--;
            n2--;
            n3--;
            c++;
        }
        return c;
    }

    static int CHAR_BIT = 8;

    // Function to find minimum of x and y
    static int min(int x, int y) {
        return y + ((x - y) & ((x - y) >> ((Integer.SIZE / 8) * CHAR_BIT - 1)));
    }

    /*
     * Method-2 : Repeated Subtraction most efficient method result same as < and >
     * operators.
     */
    private static int findSmallestMethod2(int x, int y, int z) {
        return Math.min(x, Math.min(y, z));
    }
}
