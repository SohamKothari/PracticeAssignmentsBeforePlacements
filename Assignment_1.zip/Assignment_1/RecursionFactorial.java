
/* 3.Find the Factorial of a number using Recursion. */
import java.util.Scanner;

class RecursionFactorial {
    private static long FactorialRec(Long N) {
        if (N == 0 || N == 1) {
            return 1;
        } else {
            return N * (FactorialRec(N - 1));
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        long Num = scan.nextLong();
        long fact = FactorialRec(Num);
        System.out.println("Factorial of " + Num + "=   " + fact);
    }
}